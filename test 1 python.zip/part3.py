#     DEFINING GLOBAL VARIABLES 
uk_average=35423
usa_average=56516
canada_average=64000
cambodian_average=5649856

#     TAKING INPUTS 
salary=int(input("enter your salary in Germany : "))
migrate=input("enter the country you want to migrate to :")

def convertSalary():    
    
    cad=1.55*salary
    usd=1.18*salary
    pound=0.91*salary
    cambodian=4847.38*salary
    # return cad,usd,pound,cambodian
    
    if(migrate=="Canada"): 
        # cad=cad
        if cad>canada_average:
            print("you will be rich in canada with salary of " +str(cad) +" CAD")
        else:
            print("you will be poor in canada with salary of "+str(cad)+" CAD")
            
    elif(migrate=="USA"):
        if usd>usa_average:
            print("you will be rich in usa with salary of " +str(usd) +" USD")
        else:
            print("you will be poor in usa with salary of "+str(usd)+" USD")
            
    elif(migrate=="UK"):
        if pound>uk_average:
            print("you will be rich in uk with salary of " +str(pound) +" UK")
        else:
            print("you will be poor in uk with salary of "+str(pound)+" UK")
            
    elif(migrate=="Cambodia"):
        if cambodian>cambodian_average:
            print("you will be rich in cambodia with salary of " +str(cambodian) +" cambodian riel")
        else:
            print("you will be poor in cambodia with salary of "+str(cambodian)+" cambodian riel")
    
convertSalary()
            
        
            
        
        
    
                
        
